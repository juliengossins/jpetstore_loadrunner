Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_url("catalog", 
		"URL=https://jpetstore.cfapps.io/catalog", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_add_cookie("SRCHUID=V=2&GUID=4B7B8A86285148CB95C39E51F1131219&dmnchg=1; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("MC1=GUID=11da2c1f504f4841bc5d9e58bad5c39a&HASH=11da&LV=201809&V=4&LU=1538119735763; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("msdn=L=en-us; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("_ga=GA1.2.648165023.1538119735; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20180831; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHUID=V=2&GUID=4B7B8A86285148CB95C39E51F1131219&dmnchg=1; DOMAIN=c.urs.microsoft.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=c.urs.microsoft.com");

	web_add_cookie("MC1=GUID=11da2c1f504f4841bc5d9e58bad5c39a&HASH=11da&LV=201809&V=4&LU=1538119735763; DOMAIN=c.urs.microsoft.com");

	web_add_cookie("msdn=L=en-us; DOMAIN=c.urs.microsoft.com");

	web_add_cookie("_ga=GA1.2.648165023.1538119735; DOMAIN=c.urs.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20180831; DOMAIN=c.urs.microsoft.com");

	web_add_header("UA-CPU", 
		"AMD64");

	web_url("iecompatviewlist.xml", 
		"URL=https://iecvlist.microsoft.com/IE11/1478281996/iecompatviewlist.xml", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://c.urs.microsoft.com/l1.dat?cw=636742492002747205&v=3&cv=9.11.16299.0&os=10.0.16299.0.0&pg=4A72F430-B40C-4D36-A068-CE33ADA5ADF9", "Referer=", ENDITEM, 
		LAST);

	lr_start_transaction("PR_02_Click_Category");

	web_url("FISH", 
		"URL=https://jpetstore.cfapps.io/catalog/categories/FISH", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.cfapps.io/catalog", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("PR_02_Click_Category",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("PR_03_Click_Product");

	web_url("FI-SW-01", 
		"URL=https://jpetstore.cfapps.io/catalog/products/FI-SW-01", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.cfapps.io/catalog/categories/FISH", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("PR_03_Click_Product",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("PR_04_Click_Item");

	web_url("EST-1", 
		"URL=https://jpetstore.cfapps.io/catalog/items/EST-1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.cfapps.io/catalog/products/FI-SW-01", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("PR_04_Click_Item",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("PR_05_AddToCart");

	web_url("Add to Cart", 
		"URL=https://jpetstore.cfapps.io/cart?add&itemId=EST-1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.cfapps.io/catalog/items/EST-1", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("PR_05_AddToCart",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("PR_06_RemoveFromCart");

	web_url("Remove", 
		"URL=https://jpetstore.cfapps.io/cart?remove&itemId=EST-1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.cfapps.io/cart", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("PR_06_RemoveFromCart",LR_AUTO);

	lr_think_time(3);

	return 0;
}